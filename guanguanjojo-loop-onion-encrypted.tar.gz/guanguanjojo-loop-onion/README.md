# 关关Jojo · guanguanjojo/loop-onion

加密 Skill 包（方案三：抬高白嫖与冒充成本，**不能**从技术上绝对禁止复制）。

## 这是什么
「卡住循环剥洋葱」——一层层挖人生循环原因，并给出可执行方案。  
**Brand:** 关关Jojo · **Handle:** `guanguanjojo` · **Skill id:** `guanguanjojo/loop-onion`

## 你怎么用
1. 关注关关Jojo，按活动要求评论「循环」获取**解锁码**（只通过私信发放）。
2. 把本文件夹下载到电脑。
3. 运行解锁（macOS / Linux）：
   ```bash
   chmod +x unlock.sh
   ./unlock.sh
   ```
   按提示输入解锁码 → 生成 `loop-onion.unlocked.md`（仅你本机）。
4. 把解锁后的「系统提示词」粘贴到 ChatGPT / Claude 等使用。

Windows：安装 [OpenSSL](https://slproweb.com/products/Win32OpenSSL.html) 后，在本目录 PowerShell 运行 `.\unlock.ps1`。

## 许可（摘要）
- ✅ 密钥持有人个人学习使用  
- ❌ 禁止二次上传网盘/群文件/公开仓库  
- ❌ 禁止删除品牌署名、改头换面冒充关关Jojo / guanguanjojo  
- ❌ 禁止售卖本 Skill 原文  

完整条款见 `LICENSE.txt`。侵权与冒充将保留追究权利（含平台投诉）。

## 指纹
文件内含品牌指纹 `GUANGUANJOJO-LOOP-ONION-v1`，便于识别盗改版本。
