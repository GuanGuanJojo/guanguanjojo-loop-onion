Write-Host "关关Jojo · guanguanjojo/loop-onion"
$Secure = Read-Host "请输入解锁码" -AsSecureString
$BSTR = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
$KEY = [Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
$enc = "payload/loop-onion.enc"
$out = "loop-onion.unlocked.md"
& openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -salt -in $enc -out $out -pass "pass:$KEY"
if ($LASTEXITCODE -eq 0) {
  Write-Host "解锁成功 → $out"
} else {
  Remove-Item $out -ErrorAction SilentlyContinue
  Write-Host "解锁失败"
  exit 1
}
