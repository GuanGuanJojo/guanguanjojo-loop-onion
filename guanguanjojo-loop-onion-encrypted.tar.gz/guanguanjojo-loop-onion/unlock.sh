#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT="loop-onion.unlocked.md"
ENC="payload/loop-onion.enc"
if [[ ! -f "$ENC" ]]; then
  echo "找不到 $ENC"; exit 1
fi
echo "关关Jojo · guanguanjojo/loop-onion"
echo "请输入解锁码（私信获得，输入时不可见）："
read -r -s KEY
echo
if openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -salt \
  -in "$ENC" -out "$OUT" -pass "pass:$KEY" 2>/dev/null; then
  echo "解锁成功 → $OUT"
  echo "请勿上传网盘或公开仓库。使用时保留文内关关Jojo 署名。"
else
  rm -f "$OUT"
  echo "解锁失败：码不对或文件损坏。"
  exit 1
fi
